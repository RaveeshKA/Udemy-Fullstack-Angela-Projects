# Run Completed Code

1. Make sure dfx is running

```
dfx start --clean
```

2. Deploy the project
```
dfx deploy
```

3. Start NPM
```
npm start
```



